# Decentralized Learning Simulator — Conflux V2 research

Simulate distributed learning protocols and execute their PyTorch training DAGs.
The discrete-event simulator models local compute, bandwidth contention, latency
and message traffic. A local executor or distributed brokers/workers then perform
the actual training and evaluation. **Simulated protocol time and execution wall
time are separate measurements.**

Protocols use explicit task references and shared compute and payload APIs.
Accuracy-dependent decisions can pause simulation for numerical feedback and
extend the DAG. See the [programming model](docs/simulator-design-improvements.md)
and run `python scripts/run_feedback.py --output output/feedback-example` for a
working example. Existing algorithms and runners use the new API; regenerate
saved workflows created before task format version 2.
For implementation steps and a minimal ring protocol, see
[adding a protocol](docs/adding-protocols.md).

## Branches

- **`main`**: shared simulator, datasets, performance improvements and algorithm implementations.
- **[`conflux-v2`](https://github.com/sacs-epfl/decentralized-learning-simulator/tree/conflux-v2)**:
  Conflux V2 development, comparison experiments and their recorded results.
- **`codex/conflux-v2-validation`**: unchanged archive of the original experiments
  and execution-source provenance.

This branch extends `main` with Conflux V2. General improvements and baselines
belong on `main`; merge `main` into this branch as it evolves.
See [Conflux V2 protocol and experiments](docs/conflux-v2.md).
See [repository structure and development workflow](docs/architecture.md).

## Setup

```sh
conda env create -f environment.yml
conda activate decentralized-learning
python -m pytest -q
```

The environment specifies Python 3.12 and the modern Torch/TorchVision versions
used for validation. CPU execution works without CUDA. For a GPU host, install a
compatible CUDA Torch build in the Conda environment. `requirements.txt` also
supports an existing environment. Both dependency files include Hugging Face
`datasets` and Flower `flwr-datasets`; speech transforms use `librosa`.

## LoRA fine-tuning

LoRA supports pretrained Hugging Face text and vision transformers with a shared frozen base per
worker and adapter-only client state. Install `requirements-lora.txt` inside your
conda environment, then run `scripts/run_lora.py` for local execution without
brokers. See [LoRA setup, CLI examples, memory model and validation](docs/lora.md).

## Algorithms

| Algorithm | CLI name / runner alias | Paper or original source | Implementation notes | Validation status |
|---|---|---|---|---|
| FedAvg / centralized FL | `fl` | [Communication-Efficient Learning of Deep Networks from Decentralized Data — AISTATS 2017](https://proceedings.mlr.press/v54/mcmahan17a.html) | Fixed local steps; uniform weights by default, example weighting optional. | Equation + integration checks |
| D-PSGD | `dpsgd` | [Can Decentralized Algorithms Outperform Centralized Algorithms? — NeurIPS 2017](https://papers.nips.cc/paper/2017/hash/f75526659f31040afeb61cb7133e4e6d-Abstract.html) | Fixed-topology train-then-average variant; differs from the original paper’s update order. | Equation + integration checks |
| AD-PSGD (A-DPSGD) | `adpsgd` | [Asynchronous Decentralized Parallel Stochastic Gradient Descent — ICML 2018](https://proceedings.mlr.press/v80/lian18a.html) | Active/passive asynchronous specialization; single-gradient passive updates. | Update + integration checks |
| Epidemic Learning | `epidemic` | [Epidemic Learning: Boosting Decentralized Learning with Randomized Communication — NeurIPS 2023](https://papers.nips.cc/paper_files/paper/2023/hash/7172e147d916eef4cb1eb30016ce725f-Abstract-Conference.html) | Changing directed/regular graphs; paper equivalence not established. | Mixing + integration checks |
| Gossip Learning | `gossip` | [Gossip Learning as a Decentralized Alternative to Federated Learning — DAIS 2019](https://www.inf.u-szeged.hu/~ihegedus/publ/dais19a.pdf) | Legacy periodic gossip and model-age weighting. | Legacy |
| Super Gossip Learning | `super-gossip` | [Budaj's EPFL thesis, §4.5 — 2024](https://www.epfl.ch/labs/sacs/wp-content/uploads/2024/07/2024-spring-lubor-1.pdf#page=23); [original project](https://github.com/sacs-epfl/async-dl) | Internal research variant; no separate peer-reviewed paper identified. | Legacy |
| Heterogeneous Gossip Learning (HGL) | `lubor` | [Budaj's EPFL thesis, Chapter 6 — 2024](https://www.epfl.ch/labs/sacs/wp-content/uploads/2024/07/2024-spring-lubor-1.pdf#page=39) | Thesis prototype; retains its historical CLI name. | Legacy |
| Shatter | `shatter`; `shatter-r2`, `shatter-r4` in runners | [Noiseless Privacy-Preserving Decentralized Learning — PoPETs 2025](https://petsymposium.org/popets/2025/popets-2025-0043.php) | Real-node chunked-exchange specialization. | Protocol checks |
| Moshpit SGD | `moshpit` | [Moshpit SGD: Communication-Efficient Decentralized Training on Heterogeneous Unreliable Devices — NeurIPS 2021](https://papers.neurips.cc/paper_files/paper/2021/hash/97275a23ca44226c9964043c8462be96-Abstract.html) | Stable-membership group collectives. | Equation checks |
| Teleportation | `teleportation`; `teleportation-ring`, `teleportation-hypercube` in runners | [Scalable Decentralized Learning with Teleportation — ICLR 2025](https://proceedings.iclr.cc/paper_files/paper/2025/hash/b3732a13897c4cea145c3bdece80de64-Abstract-Conference.html) | Algorithm 1 specialization; hypercube is not the paper's Base-2 graph. | Equation checks |
| D-Local-SGD | `d-local-sgd-ring` in runners | [A Unified Theory of Decentralized SGD with Changing Topology and Local Updates — ICML 2020](https://proceedings.mlr.press/v119/koloskova20a.html) | Fixed full-participation ring with configurable local updates. | Shared Teleportation checks |
| Quasi-Global Momentum / DSGDm controls | `qgm`; `dsgdm`, `dsgd` in runners | [Quasi-global Momentum: Accelerating Decentralized Deep Learning on Heterogeneous Data — ICML 2021](https://proceedings.mlr.press/v139/lin21c.html) | One-step QG-DSGDm, optional Nesterov, persistent local-momentum and plain controls. | [Reference, replay and CIFAR checks](docs/qgm.md#validation) |
| CHOCO-SGD | `choco` | [Decentralized Stochastic Optimization and Gossip Algorithms with Compressed Communication — ICML 2019](https://proceedings.mlr.press/v97/koloskova19a.html); [deep-learning extension — ICLR 2020](https://arxiv.org/abs/1907.09356) | Persistent public estimates; Top-k/random-k compression; explicit local-SGD block extension. | Equation + compressor reference checks |
| DSpodFL | `dspodfl` | [Decentralized Sporadic Federated Learning: A Unified Algorithmic Framework with Convergence Guarantees — ICLR 2025](https://proceedings.iclr.cc/paper_files/paper/2025/hash/9521b6e7f33e039e7d92e23f5e37bbf4-Abstract-Conference.html) | One-step rule and explicit local-SGD block extension. | Equation checks |
| DeMo | `demo` | [DeMo: Decoupled Momentum Optimization — ICLR 2026](https://proceedings.iclr.cc/paper_files/paper/2026/hash/17790fc9b4828206f99a0dea35da3657-Abstract-Conference.html) | Reference Signum optimizer; ring all-gather and CNN adaptation. | Optimizer reference check |
| Conflux (original) | `conflux` | Unpublished prototype; related sampling work: [Practical Federated Learning without a Server — EuroMLSys 2025](https://euromlsys.eu/pdf/euromlsys25-10.pdf). | Chunked sampling prototype; not an implementation of Plexus. | Legacy |
| Conflux V2 | `conflux-v2` | [Research protocol documentation](docs/conflux-v2.md); unpublished prototype. | Research branch only. | Protocol checks + research experiments |

[Baseline contracts and sources](docs/peer-baselines.md),
[DSpodFL semantics](docs/dspodfl.md), [DeMo semantics](docs/demo.md),
[CHOCO-SGD semantics and usage](docs/choco.md),
[Quasi-Global Momentum](docs/qgm.md).
Paper links identify the source algorithms, not a claim of exact paper reproduction.
Validation labels describe specific checks, not a certification of every option.
[Validation contracts, evidence and remaining gaps](docs/baseline-validation.md).
Stable-membership restrictions, optimizer assumptions and adaptations are
explicit in those documents. Legacy entries have not all been re-audited. PushSum remains on its existing experimental branch.

## Run a small comparison

For configuration files and parameter sweeps, use the shared experiment runner:

```sh
python scripts/run_experiment.py experiments/smoke.yaml
python scripts/run_experiment.py experiments/food101.yaml --plan
```

YAML/JSON files support shared settings, Cartesian matrices or named runs, and
CLI overrides. Each run gets its own process, log, resolved configuration and
manifest. See [experiment configuration](docs/experiments.md) for execution modes,
output protection, and the pinned Food-101 LoRA comparison.

This runs real protocol-generated DAGs on CPU, with synthetic data and no downloads:

```sh
python scripts/validate_algorithms.py --variants shatter-r2 moshpit \
  --peers 8 --sample-size 4 --profiles uniform heterogeneous \
  --partitioners iid dirichlet --seeds 0 --duration 20 --test-period 5 \
  --output output/smoke
```

The runner also supports bundled handwritten digits (`--dataset digits`).
`validate_conflux.py` remains a compatibility entry point for older commands.
CIFAR-10 and Tiny ImageNet can load directly from Hugging Face. For offline
benchmark runs, save them with `scripts/prepare_dataset.py` and pass the directory
to `run_cifar.py` / `run_tiny.py`; see [dataset configuration](docs/datasets.md).
Each run records parameters, versions, a source hash and per-run outputs.

At fixed simulated times, accuracy is the mean of all nodes' latest completed
local checkpoints, including nodes that have not recently updated. No uncharged
global parameter average is constructed. Unreached accuracy targets are censored.
Controlled heterogeneous profiles vary compute and bandwidth independently;
these profiles are distinct from FedScale traces (`data/fedscale_traces`).

Optional [loss-based membership inference audits](docs/membership-inference.md)
measure leakage through a participant's own local model, using independent
nonmember calibration and class-matched evaluation cohorts. Run
`python scripts/compare_membership.py --output output/membership-comparison`
for a matched-training-budget D-PSGD/Shatter comparison on offline digits data.
Attack results include balanced accuracy, ROC-AUC, TPR and observed FPR; empirical
attack resistance is not a formal privacy guarantee.
Add `--view incoming` and use a fresh output directory to attack actual delivered
D-PSGD models and Shatter chunks. Missing chunks are filled from receiver-known
state; outputs report observation coverage and the fraction of state received.
`--cohort-policy global_nonmembers` retains the global nonmember label distribution;
the default `class_matched` policy controls for label-distribution leakage. Report
the policy when comparing results, especially under non-IID partitions.

## Coordinator and brokers

Generate a DAG without executing it:

```sh
python main.py --algorithm moshpit --dataset synthetic --model mlp \
  --peers 8 --group-size 4 --momentum 0 --rounds 3 --dry-run
```

Without `--dry-run`, the coordinator waits for its configured brokers. Start a
broker with `python broker.py --coordinator tcp://HOST:5555 --port 5556 --workers 2`.
All registered settings types are supported by the shared broker registry.
Use `--from-dir PATH` to load a saved workflow/settings pair.

## Performance and validation

Shared improvements include direct immutable model-state copying, bounded DAG
execution and reconstruction caches, cached dataset tensors, reproducible training,
GPU workspaces and guarded batching of independent SGD tasks. These optimizations
preserve algorithm updates; CUDA equivalence tests compare complete model states.

The local execution runners enable supported CUDA optimizations automatically:
`--no-gpu-residency` and `--no-training-batching` opt out. CPU and unsupported
workloads use the reference path. [Performance details](docs/performance.md).

Default pytest discovery covers the maintained tests. Older protocol fixtures
using removed settings/reference APIs are retained in `tests/legacy` for migration
and excluded from default discovery. The old Task tests have been migrated to the
current reference/index API. Historical results remain on the research/archive
branches; new experiments should use fresh output directories.
