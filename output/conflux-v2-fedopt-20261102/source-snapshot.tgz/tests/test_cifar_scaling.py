from dasklearn.simulation.moshpit.simulation import MoshpitSimulation
from dasklearn.simulation.moshpit.settings import MoshpitSettings
import numpy as np
import pandas as pd
import pytest

from datasets import Dataset
from dasklearn.datasets.huggingface import allocate_indices
from dasklearn.session_settings import SessionSettings, LearningSettings
from dasklearn.tasks.local import execute_local
from helpers import settings, simulate


@pytest.mark.parametrize("partitioner", ["iid", "dirichlet"])
def test_cifar_partition_is_complete_disjoint_and_reproducible(partitioner):
    labels = np.repeat(np.arange(10), 5000)
    config = SessionSettings(algorithm="test", seed=42, work_dir="", dataset="cifar10", participants=128,
                             partitioner=partitioner, alpha=.3, learning=LearningSettings(.1, 0, 0, 8, 1))
    data = Dataset.from_dict({"label": labels})
    parts = allocate_indices(data, config, min_size=8)
    assert parts == allocate_indices(data, config, min_size=8)
    assert min(map(len, parts)) >= 8
    assert sorted(i for part in parts for i in part) == list(range(len(labels)))


@pytest.mark.asyncio
async def test_streaming_executor_preserves_every_snapshot(tmp_path):
    frames = []
    for retain in [True, False]:
        sim = simulate(MoshpitSimulation, settings(MoshpitSettings, tmp_path / str(retain),
            group_size=3))
        status = []
        result = execute_local(sim, retain_results=retain, progress=status.append)
        if not retain:
            assert result == {}
        assert status[-1]["completed"] == len(sim.workflow_dag.tasks)
        sim.merge_accuracies_files()
        frames.append(pd.read_csv(sim.data_dir + "/accuracies.csv").sort_values(["time", "peer"]).reset_index(drop=True))
    pd.testing.assert_frame_equal(*frames)


def test_balanced_evaluation_subset_is_reproducible_and_stays_in_its_split():
    import torch
    from dasklearn.datasets.cifar10 import CifarPartition
    labels=torch.arange(10).repeat_interleave(40);features=torch.zeros(400,3,2,2)
    indices=np.concatenate([np.arange(i*40,i*40+20) for i in range(10)])
    partition=CifarPartition(features,labels,indices)
    subset=partition.evaluation_subset(100)
    assert subset is partition.evaluation_subset(100)
    assert np.isin(subset.indices,indices).all()
    assert np.array_equal(np.bincount(labels[subset.indices]),np.full(10,10))
    assert np.array_equal(subset.indices,CifarPartition(features,labels,indices).evaluation_subset(100).indices)
    assert partition.evaluation_subset(1000) is partition
    with pytest.raises(ValueError):partition.evaluation_subset(11)
