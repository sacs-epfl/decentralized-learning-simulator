import pickle
import copy
from functools import lru_cache
from typing import Optional

import torch

from dasklearn.models.Model import Model


def serialize_model(model: torch.nn.Module) -> bytes:
    return pickle.dumps(model.state_dict())


def unserialize_model(serialized_model: bytes, dataset: str, architecture: Optional[str] = None, settings=None) -> torch.nn.Module:
    model = create_model(dataset, architecture=architecture, settings=settings)
    model.load_state_dict(pickle.loads(serialized_model))
    return model


@lru_cache(maxsize=4)
def _model_structure(dataset: str, architecture: Optional[str]):
    # Only used when every state entry will be overwritten. Keep the prototype
    # private and on CPU; callers always receive independent parameters/buffers.
    # Constructing it must not perturb task-specific training randomness.
    with torch.random.fork_rng(devices=[]):
        return create_model(dataset, architecture=architecture).cpu()


def create_model_structure(dataset: str, architecture: Optional[str] = None, settings=None) -> torch.nn.Module:
    """Fresh model structure for a complete state overwrite, without reinitialization."""
    if settings is not None and settings.lora:
        return create_model(dataset, architecture, settings=settings)
    return copy.deepcopy(_model_structure(dataset, architecture))


def copy_model_state(model: torch.nn.Module, dataset: str, architecture: Optional[str] = None, settings=None) -> torch.nn.Module:
    """Equivalent state transfer to serialize/unserialize, without the wire encoding."""
    from dasklearn.lora import LoRAModel
    if isinstance(model, LoRAModel):
        result = copy.deepcopy(model).cpu()
        result.zero_grad(set_to_none=True)
        return result
    result = create_model_structure(dataset, architecture)
    result.load_state_dict(model.state_dict())
    return result


def create_model(dataset: str, architecture: Optional[str] = None, settings=None) -> Model:
    if settings is not None and settings.lora:
        from dasklearn.lora import LoRAModel, LoRASpec
        return LoRAModel(LoRASpec.from_settings(settings))
    if dataset == "digits":
        return torch.nn.Sequential(torch.nn.Linear(64, 32), torch.nn.ReLU(), torch.nn.Linear(32, 10))
    if dataset == "synthetic":
        return torch.nn.Sequential(torch.nn.Linear(16, 32), torch.nn.ReLU(), torch.nn.Linear(32, 4))
    if dataset == "cifar10":
        if not architecture or architecture == "lenet":
            from dasklearn.models.cifar10 import LeNet
            return LeNet()
        elif architecture == "gnlenet":
            from dasklearn.models.cifar10 import GNLeNet
            return GNLeNet(input_channel=3, output=10, model_input=(32, 32))
        elif architecture in ["resnet18", "mobilenet_v3_large"]:
            import torchvision.models as tormodels
            return tormodels.__dict__[architecture](num_classes=10)
        else:
            raise RuntimeError("Unknown model architecture for CIFAR10: %s" % architecture)
    elif dataset == "femnist":
        from dasklearn.models.femnist import CNN
        return CNN()
    elif dataset == "movielens":
        from dasklearn.models.MovieLens import MatrixFactorization
        return MatrixFactorization()
    elif dataset == "google_speech":
        from dasklearn.models.resnet_speech import resnet34
        return resnet34(num_classes=35, in_channels=1)
    elif dataset == "tiny_imagenet":
        if architecture in ["resnet18", "mobilenet_v3_large"]:
            import torchvision.models as tormodels
            return tormodels.__dict__[architecture](num_classes=200)
        else:
            raise RuntimeError("Unknown model architecture for Tiny Imagenet: %s" % architecture)
    else:
        raise RuntimeError("Unknown dataset %s" % dataset)
