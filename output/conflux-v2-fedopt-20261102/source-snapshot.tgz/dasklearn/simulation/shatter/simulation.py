from typing import Dict
import math
from typing import List, Tuple
from dasklearn.session_settings import SessionSettings
from dasklearn.simulation.events import *
from dasklearn.simulation.shatter.client import ShatterClient
from dasklearn.simulation.simulation import Simulation

import networkx as nx

from dasklearn.tasks.task import Task
from dasklearn.tasks.references import TaskRef


class ShatterSimulation(Simulation):
    CLIENT_CLASS = ShatterClient

    def __init__(self, settings: SessionSettings):
        if settings.k < 1 or settings.participants < 1:
            raise ValueError("Shatter requires positive participant and chunk counts (--k)")
        super().__init__(settings)
        self.oracle_services['availability'] = self.availability_snapshot
        self.topologies = []
        self.finished: Dict[int, List[Tuple[str, int]]] = {}
        if self.settings.r == 0:
            self.settings.r = max(1, math.floor(math.log2(self.settings.participants * self.settings.k)))
        vertices = settings.participants * settings.k
        if not 0 < settings.r < vertices or settings.r * vertices % 2:
            raise ValueError("Shatter degree must be below the virtual-node count and give an even degree sum")

        self.register_event_callback(START_ROUND, "start_round")
        self.register_event_callback(FINISH_TRAIN, "finish_train")
        self.register_event_callback(SEND_CHUNKS, "send_chunks")

    def set_finished(self, round_nr: int, model: Tuple[str, int], was_online: bool = True):
        if round_nr not in self.finished:
            self.finished[round_nr] = []
        self.finished[round_nr].append(model if was_online else None)

        if len(self.finished[round_nr]) == self.settings.participants:
            self.logger.info("All clients finished round %d (t=%.3f)", round_nr, self.cur_time_in_sec())

            # Should we test?
            if self.settings.test_method == "global" and self.settings.test_interval > 0 and round_nr % self.settings.test_interval == 0:
                # Aggregate non-None models
                models = [m for m in self.finished[round_nr] if m is not None]
                task_name = Task.generate_name("agg")
                data = {"models": models, "round": round_nr, "peer": 0}
                task = self.clients[0].create_compute_task("aggregate", data, name=task_name)

                # Test the aggregated model
                test_task_name = "test_%d" % round_nr
                task = self.clients[0].create_compute_task("test", {
                    "model": TaskRef(task_name, 0), "round": round_nr,
                    "time": self.current_time, "peer": 0
                }, name=test_task_name)

            self.finished.pop(round_nr)
            self.topologies[round_nr - 1] = None

    def add_topology(self):
        seed = self.settings.seed + len(self.topologies)
        g = nx.random_regular_graph(self.settings.r, self.settings.participants * self.settings.k, seed=seed)
        g = g.to_directed()
        self.topologies.append(g)
