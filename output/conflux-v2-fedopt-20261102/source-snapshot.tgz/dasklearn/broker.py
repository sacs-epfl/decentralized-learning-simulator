import asyncio
import threading
from asyncio import ensure_future

import psutil
from dasklearn.util.utils import start_profile, stop_profile
import torch.multiprocessing as multiprocessing
from torch.multiprocessing.reductions import shared_cache as mp_torch_sc
import pickle
import random
from asyncio.subprocess import Process
from typing import List, Optional, Set, Tuple

import setproctitle

from dasklearn.communication import Communication
from dasklearn.functions import *
from dasklearn.algorithms import settings_classes
from dasklearn.tasks.dag import WorkflowDAG
from dasklearn.tasks.task import Task
from dasklearn.tasks.references import TaskRef
from dasklearn.util.logging import setup_logging
from dasklearn.worker import Worker

torch.multiprocessing.set_sharing_strategy('file_system')


def worker_proc(shared_queue, result_queue, index, settings):
    setproctitle.setproctitle("[Worker %d]" % index)
    torch.set_num_threads(settings.torch_threads)
    worker = Worker(shared_queue, result_queue, index, settings)
    worker.start()


class Broker:

    def __init__(self, args):
        self.args = args
        self.brokers_to_clients: Dict = {}
        self.clients_to_brokers: Dict = {}
        self.logger = logging.getLogger(self.__class__.__name__)
        self.settings: Optional[SessionSettings] = None
        self.dag: Optional[WorkflowDAG] = None
        self.coordinator_socket = None
        self.communication: Optional[Communication] = None
        self.broker_addresses: Dict[str, str] = {}

        self.workers: List[Process] = []
        self.psutil_workers: List = []
        self.worker_result_queues: List = []
        self.worker_result_queue = asyncio.Queue()
        self.read_worker_results_task = None
        self.monitor_task = None
        self.worker_queue = None
        self.items_in_worker_queue: int = 0
        self.workers_ready: bool = False
        self.incremental = False
        self.pending_tasks: List[Task] = []
        self.identity: str = "broker_%s" % ''.join(random.choice('0123456789abcdef') for _ in range(6))

        # For statistics
        self.start_time: float = -1
        self.time_last_check: float = -1
        self.task_start_times: Dict[str, float] = {}
        self.task_statistics: List[Tuple] = []
        self.completed_tasks: int = 0
        self.completed_tasks_last_check: int = 0  # Used to compute the task/sec throughput

        self.logger.info("Broker %s initialized", self.identity)

    def write_statistics(self):
        broker_id = self.identity.split("_")[1]
        with open(os.path.join(self.settings.data_dir, "tasks_%s.csv" % self.identity), "w") as tasks_file:
            tasks_file.write("broker,task_name,function,worker,transfer_to_time,execute_time,transfer_from_time,total_time\n")
            for task_stats in self.task_statistics:
                task_stats_str = "%s,%s,%d,%f,%f,%f,%f" % task_stats
                tasks_file.write("%s,%s\n" % (broker_id, task_stats_str))

    async def monitor(self):
        self.logger.info("Started monitor")
        broker_id = self.identity.split("_")[1]
        process = psutil.Process(os.getpid())

        resources_file_path = os.path.join(self.settings.data_dir, "resources_%s.csv" % self.identity)
        workers_file_path = os.path.join(self.settings.data_dir, "worker_resources_%s.csv" % self.identity)
        with open(resources_file_path, "w") as resources_file:
            resources_file.write("broker,time,queue_items,num_models,cpu_percent,phys_mem_usage,virt_mem_usage,"
                                 "shared_mem_usage,mp_torch_cache_items,completed_tasks,tasks_throughput,bytes_up,bytes_down\n")
        with open(workers_file_path, "w") as workers_resources_file:
            workers_resources_file.write("broker,time,worker,cpu_percent\n")

        while True:
            try:
                with open(resources_file_path, "a") as resources_file:
                    cpu_usage = psutil.cpu_percent()
                    mem_info = process.memory_info()
                    phys_mem = mem_info.rss
                    virt_mem = mem_info.vms
                    num_models = self.dag.get_num_models()
                    shared_mem = 0 if not hasattr(mem_info, "shared") else mem_info.shared
                    mp_torch_cache_items = len(mp_torch_sc)

                    # Calculate the task/sec throughput
                    if self.time_last_check == -1:
                        self.time_last_check = self.start_time

                    time_diff = time.time() - self.time_last_check
                    tasks_diff = self.completed_tasks - self.completed_tasks_last_check
                    self.completed_tasks_last_check = self.completed_tasks
                    self.time_last_check = time.time()

                    resources_file.write("%s,%f,%d,%d,%f,%d,%d,%d,%d,%d,%f,%d,%d\n" % (
                        broker_id, time.time() - self.start_time, self.items_in_worker_queue, num_models,
                        cpu_usage, phys_mem, virt_mem, shared_mem, mp_torch_cache_items, self.completed_tasks,
                        tasks_diff / time_diff, self.communication.bytes_sent, self.communication.bytes_received))

                with open(workers_file_path, "a") as workers_resources_file:
                    # Get the subprocesses and their CPU utilization
                    for worker_ind, worker_proc in enumerate(self.psutil_workers):
                        try:
                            cpu_usage = worker_proc.cpu_percent()
                        except (ProcessLookupError, psutil.ZombieProcess):
                            continue
                        workers_resources_file.write("%s,%f,%s_%d,%f\n" % (broker_id, time.time() - self.start_time,
                                                                           broker_id, worker_ind, cpu_usage))

                await asyncio.sleep(1)
            except Exception as exc:
                self.logger.exception(exc)
                self.shutdown_everyone()
                break

    async def start_workers(self):
        self.logger.info("Starting %d workers...", self.args.workers)
        self.worker_queue = multiprocessing.Queue()
        self.read_worker_results_task = asyncio.create_task(self.worker_result_queue_task())
        self.monitor_task = asyncio.create_task(self.monitor())
        for worker_ind in range(self.args.workers):
            await self.start_worker(worker_ind)

        # Workers ready - clear any pending tasks
        self.workers_ready = True
        for pending_task in self.pending_tasks:
            self.put_in_worker_queue(pending_task)
        self.pending_tasks = []

    def worker_result_queue_thread(self, mp_queue, loop):
        while True:
            try:
                item = mp_queue.get()
                if item is None:  # Sentinel value to end loop
                    break

                asyncio.run_coroutine_threadsafe(self.worker_result_queue.put(item), loop)
            except KeyError:
                self.logger.warning("KeyError in free_dead_references()")
            except Exception as exc:
                self.logger.exception(exc)
                asyncio.run_coroutine_threadsafe(self.worker_result_queue.put(("error", None, None)), loop)
                break

    async def worker_result_queue_task(self):
        self.logger.info("Starting result queue task")
        while True:
            try:
                task_name, res, info = await self.worker_result_queue.get()
                if task_name == "error":
                    if self.incremental:
                        self.communication.send_message_to_coordinator(pickle.dumps({
                            "type": "execution_result", "task": res,
                            "error": "Worker failed while executing task " + str(res),
                        }))
                        self.items_in_worker_queue -= 1
                        continue
                    # One of the workers encountered an exception - stop everything
                    task_name = res
                    task = self.dag.tasks[task_name]
                    self.logger.error("Failed task %s: %s", task_name, task)
                    self.logger.error("Failed task inputs (resolved: %d): %s", task.inputs_resolve, task.inputs)
                    self.logger.error("Failed task outputs: %s", task.outputs)
                    self.logger.error("Failed task data: %s", task.data)
                    self.logger.error("Worker encountered an exception - shutting down everything")
                    self.shutdown_everyone()
                    break

                task = self.dag.tasks[task_name]
                task.done = True
                self.items_in_worker_queue -= 1
                self.completed_tasks += 1
                if self.completed_tasks % 1000 == 0:
                    self.logger.info("Completed %d tasks", self.completed_tasks)

                received_by_broker_time = time.time()
                received_by_worker_time = info["received"]
                finished_time = info["finished"]
                task_start_time = self.task_start_times[task_name]
                task_stats = (task.name, task.func, info["worker"],
                              received_by_worker_time - task_start_time,
                              finished_time - received_by_worker_time,
                              received_by_broker_time - finished_time,
                              received_by_broker_time - task_start_time)
                self.task_statistics.append(task_stats)

                self.logger.info("Task %s completed", task.name)

                if self.incremental:
                    self.communication.send_message_to_coordinator(pickle.dumps({
                        "type": "execution_result", "task": task.name, "result": res,
                    }))
                    task.clear_data()
                    continue

                # If this is a sink task, inform the coordinator about the result
                if not task.outputs:
                    # This is a sink task with no further outputs - send the result back to the coordinator
                    msg = pickle.dumps({"type": "result", "task": task.name, "result": res})
                    self.communication.send_message_to_coordinator(msg)
                else:
                    # Some broker needs this result - get all brokers we need to inform about this result
                    brokers_to_inform: Set[str] = set()
                    for next_task, _ in task.outputs:
                        peer_next_task = next_task.data["peer"]
                        brokers_to_inform.add(self.clients_to_brokers[peer_next_task])

                    for broker_to_inform in brokers_to_inform:
                        if broker_to_inform == self.identity:
                            self.handle_task_result(task, res)
                        else:
                            msg = pickle.dumps({"type": "result", "task": task.name, "result": res})
                            self.communication.send_message_to_broker(broker_to_inform, msg)

                task.clear_data()  # Clean up the memory of the completed task
            except Exception as exc:
                self.logger.exception(exc)
                self.shutdown_everyone()
                break

    async def start_worker(self, index: int):
        worker_result_queue = multiprocessing.Queue()
        self.worker_result_queues.append(worker_result_queue)
        threading.Thread(target=self.worker_result_queue_thread, args=(worker_result_queue, asyncio.get_event_loop()), daemon=True).start()

        proc = multiprocessing.Process(target=worker_proc, args=(self.worker_queue, worker_result_queue, index, self.settings))
        proc.start()
        self.workers.append(proc)
        self.psutil_workers.append(psutil.Process(proc.pid))
        self.logger.info("Worker %d started: %s", index, proc)

    def connect_to_brokers(self):
        self.logger.info("Connecting to other brokers: %s", self.broker_addresses)
        for broker_name, broker_address in self.broker_addresses.items():
            if broker_name == self.identity:
                continue

            self.communication.connect_to(broker_name, broker_address)

    def shutdown(self):
        self.write_statistics()

        for worker_proc in self.workers:
            worker_proc.terminate()

        asyncio.get_event_loop().call_later(2, asyncio.get_event_loop().stop)

        if self.args.profile:
            stop_profile(self.settings.data_dir, is_broker=True)

    def shutdown_everyone(self):
        self.logger.error("Will send shutdown signal to all nodes")
        msg = pickle.dumps({"type": "shutdown"})
        self.communication.send_message_to_all_brokers(msg)
        self.communication.send_message_to_coordinator(msg)
        self.shutdown()

    def put_in_worker_queue(self, task: Task):
        self.logger.info("Putting task %s in worker queue", task.name)
        self.items_in_worker_queue += 1
        self.worker_queue.put((task.name, task.func, task.data, task.operation))

    def schedule_task(self, task: Task):
        """
        Schedule the task on one of the available workers.
        """
        if task.scheduled:
            return
        task.scheduled = True
        self.task_start_times[task.name] = time.time()
        if not self.workers_ready:
            self.logger.info("Broker enqueueing task %s since workers are not ready yet", task.name)
            self.pending_tasks.append(task)
        else:
            self.logger.debug("Broker dispatching task %s to workers", task.name)
            self.put_in_worker_queue(task)

    def handle_task_result(self, task: Task, res):
        """
        We received a task result - either locally or from another worker. Handle it.
        """
        self.logger.debug("Handling result of task %s", task)
        if not isinstance(res, (list, tuple)):
            raise RuntimeError("Task result must be a list or tuple")

        for idx, res_at_idx in enumerate(res):
            for next_task, next_task_idx in task.outputs:
                if (not next_task.scheduled and next_task.data["peer"] in self.brokers_to_clients[self.identity]
                        and idx == next_task_idx):
                    next_task.set_data(TaskRef(task.name, next_task_idx), res_at_idx)
                    if next_task.has_all_inputs():
                        self.schedule_task(next_task)

    def on_message(self, identity: str, msg: Dict):
        if identity == "coordinator" and msg["type"] == "config":  # Configuration received from the coordinator
            self.logger.info("Received configuration from the coordinator")
            self.start_time = time.time()
            self.incremental = msg.get("incremental", False)
            self.broker_addresses = msg["brokers"]
            self.brokers_to_clients = msg["brokers_to_clients"]

            # Build the reverse map
            for broker, clients in self.brokers_to_clients.items():
                for client in clients:
                    self.clients_to_brokers[client] = broker

            # Load the settings based on the class
            name_to_cls = settings_classes()
            self.settings = name_to_cls[msg["settings_class"]].from_dict(msg["settings"])
            os.makedirs(self.settings.data_dir, exist_ok=True)
            setup_logging(self.settings.data_dir, "%s.log" % self.identity, log_level=self.settings.log_level)
            self.dag = WorkflowDAG.unserialize(msg["dag"])
            self.dag.build_task_indices()
            self.connect_to_brokers()
            ensure_future(self.start_workers())
        elif identity == "coordinator" and msg["type"] == "execute":
            if not self.incremental:
                raise RuntimeError("Incremental execution requires incremental configuration")
            task = Task(msg["task"], msg["func"], msg["data"], operation=msg.get("operation"))
            if task.name in self.dag.tasks:
                raise ValueError(f"Duplicate execution request: {task.name}")
            self.dag.tasks[task.name] = task
            self.schedule_task(task)
        elif identity == "coordinator" and msg["type"] == "tasks":
            for task_name in msg["tasks"]:
                # Enqueue tasks
                task = self.dag.tasks[task_name]
                self.schedule_task(task)
        elif msg["type"] == "shutdown":
            self.logger.info("Received shutdown signal - stopping")
            self.shutdown()
        elif msg["type"] == "result":
            self.logger.info("Received task %s result from %s", msg["task"], identity)
            task = self.dag.tasks[msg["task"]]
            self.handle_task_result(task, msg["result"])
        else:
            raise RuntimeError("Unknown message with type %s" % msg["type"])

    async def start(self):
        self.communication = Communication(self.identity, self.args.port, self.on_message, is_broker=True)
        self.communication.start()
        self.communication.connect_to_coordinator(self.args.coordinator, getattr(self.args, "advertise_host", None))

        if self.args.profile:
            start_profile()
